let btn = document.querySelector('.btn'),
    input = document.querySelector('.input'),
    timeOut = document.querySelector('.time'),
    gameBox = document.querySelector('.game__block'),
    time = 0,
    score = 0,
    interval = 0;
    
btn.addEventListener('click', (event) => {
    event.preventDefault()
    if(input.value > 4) {
        time = input.value
        input.value = ''
        score = 0
        clearInterval(interval)
        start()
        let result = document.querySelector('.result')
        if(result) {
            result.style.display = 'none'
        }
    }
})

gameBox.addEventListener('click', (event) => {
    if(event.target.classList.contains('ball')) {
        score++
        event.target.remove()
        createBall()
    }
})




function start() {
    btn.disabled = true
    timeOut.innerHTML = time
    interval = setInterval(() => {
        decrease()
    }, 1000);
    createBall()
}

function decrease() {
    if(time == 0) {
        endGame()
    }else {
        let currentTime = --time
        timeOut.innerHTML = currentTime
    }
}

function endGame() {
    gameBox.innerHTML = `<h2 class="result">Вы набрали: ${score} очков</h2>`
    btn.disabled = false
}

function createBall() {
    let ball = document.createElement('div')
    ball.classList.add('ball')
    let coor = gameBox.getBoundingClientRect()
    let x = random(0, coor.width - random(20,100))
    let y = random(0, coor.height - random(20,100))
    
    ball.style.width =  ball.style.height = random(20,100) + 'px' 
    ball.style.background = setColor(ball)
    ball.style.top = y + 'px'
    ball.style.left = x + 'px'
    gameBox.append(ball)
}

function random(min,max){
    return Math.floor(Math.random() * (max + 1 - min) + min)
}


function randomred() {
    return Math.floor(Math.random() * 255);
  }
  
  function setColor(el) {
    el.style.background = `rgb(${randomred()}, ${randomred()}, ${randomred()})`;
  }

  function randomForm() {
    let index = Math.floor(Math.random() * form.length)
    // return form[index]
    console.log(index);
  }



    let form = [
    'border-radius: 50%,',
    'clip-path: polygon(50% 0% 0% 100% 100% 100%);'
 // let polOne = polygon(50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%),
//   polTwo = polygon(50% 0%, 0% 100%, 100% 100%);
//   polThree = polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%);
//   polFour = polygon(50% 0%, 100% 38%, 82% 100%, 18% 100%, 0% 38%);
//   polFive = polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%);
//   polSix = polygon(50% 0%, 90% 20%, 100% 60%, 75% 100%, 25% 100%, 0% 60%, 10% 20%);
//   polSeven = polygon(30% 0%, 70% 0%, 100% 30%, 100% 70%, 70% 100%, 30% 100%, 0% 70%, 0% 30%);
//   polEight = polygon(50% 0%, 83% 12%, 100% 43%, 94% 78%, 68% 100%, 32% 100%, 6% 78%, 0% 43%, 17% 12%);
//   polNine = polygon(50% 0%, 80% 10%, 100% 35%, 100% 70%, 80% 90%, 50% 100%, 20% 90%, 0% 70%, 0% 35%, 20% 10%);
//   polTen = polygon(20% 0%, 80% 0%, 100% 20%, 100% 80%, 80% 100%, 20% 100%, 0% 80%, 0% 20%);
//   polEl = polygon(20% 0%, 0% 20%, 30% 50%, 0% 80%, 20% 100%, 50% 70%, 80% 100%, 100% 80%, 70% 50%, 100% 20%, 80% 0%, 50% 30%); */
//   insert = inset(5% 20% 15% 10%),
//   circle = circle(50% at 50% 50%);
  ]


 
